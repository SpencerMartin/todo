package com.example.spencer.todo_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Spencer on 5/3/2016.
 */
public class MyListAdapter extends ArrayAdapter<Task> {

    private final Context context;
    private final ArrayList<Task> itemsArrayList;

    public MyListAdapter(Context context, ArrayList<Task> itemsArrayList) {
        super(context, R.layout.list_item, itemsArrayList);
        this.context = context;
        this.itemsArrayList = itemsArrayList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // 1. Create inflater
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        // 2. Get rowView from inflater
        View rowView = inflater.inflate(R.layout.list_item, parent, false);
        // 3. Get the two text view from the rowView
        TextView taskView = (TextView) rowView.findViewById(R.id.taskText);
        TextView categoryView = (TextView) rowView.findViewById(R.id.categoryText);
        // 4. Set the text for textView
        taskView.setText(itemsArrayList.get(position).getTaskName());
        categoryView.setText(itemsArrayList.get(position).getCategory());
        // 5. return rowView
        return rowView;
    }

}
