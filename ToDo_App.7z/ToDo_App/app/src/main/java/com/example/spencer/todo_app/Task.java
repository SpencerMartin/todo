package com.example.spencer.todo_app;

import java.lang.Object;
import java.util.Calendar;

/**
 * Created by Spencer on 5/3/2016.
 */
public class Task extends Object {

    String mTaskName,
            mCategory,
            mTaskDate;

    public Task() {
        mTaskName = "DefaultConName";
        mCategory = "DefaultConCat";
        Calendar c = Calendar.getInstance();
        mTaskDate = new StringBuilder().append(c.MONTH).append("/")
                .append(c.DAY_OF_MONTH).append("/").append(c.YEAR).toString();
    }

    public Task(String name) {
        mTaskName = name;
        mCategory = "DefaultCat";
        Calendar c = Calendar.getInstance();
        mTaskDate = new StringBuilder().append(c.MONTH).append("/")
                .append(c.DAY_OF_MONTH).append("/").append(c.YEAR).toString();
    }

    Task(String name, String cat, Calendar c) {
        mTaskName = name;
        mCategory = cat;
        mTaskDate = new StringBuilder().append(c.MONTH).append("/")
                .append(c.DAY_OF_MONTH).append("/").append(c.YEAR).toString();
    }

    Task(String name, String cat, String date) {
        mTaskName = name;
        mCategory = cat;
        mTaskDate = date;
    }

    public String getTaskName() {
        return mTaskName;
    }

    public String getCategory() {
        return mCategory;
    }

    public String getTaskDate() {
        return mTaskDate;
    }

    public void setCategory(String category) {
        mCategory = category;
    }

    public void setTaskName(String name) {
        mTaskName = name;
    }

    public void setTaskDate(Calendar c) {
        mTaskDate = new StringBuilder().append(c.MONTH).append("/")
                .append(c.DAY_OF_MONTH).append("/").append(c.YEAR).toString();
        ;
    }

    public void setTaskDate(String str) {
        mTaskDate = str;
        ;
    }

}
