package com.example.spencer.todo_app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final String STORAGE_FILENAME = "Task_Array";
    ArrayList<Task> listOfTasks = new ArrayList<Task>();
    MyListAdapter adapter;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TinyDB tinydb = new TinyDB(this);
        ArrayList<Task> temp;
        temp = tinydb.getListObject("taskArray", Task.class);
        listOfTasks = temp;

        // 1. pass context and data to the custom adapter
        adapter = new MyListAdapter(this, listOfTasks);

        //2. setAdapter
        listView = (ListView) findViewById(R.id.listview);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {
                inspectTask(position);
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();  // Always call the superclass method first

        TinyDB tinydb = new TinyDB(this);

        tinydb.putListObject("taskArray", listOfTasks);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_add_new) {
            newTask();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void inspectTask(int position) {
        Context context = getApplicationContext();
        Intent i = new Intent(context, Inspect.class);
        i.putExtra("position", position);
        i.putExtra("taskName", listOfTasks.get(position).getTaskName());
        i.putExtra("taskCat", listOfTasks.get(position).getCategory());
        i.putExtra("taskDate", listOfTasks.get(position).getTaskDate());
        startActivityForResult(i, 2);
    }


    public void newTask() {
        Context context = getApplicationContext();
        Intent i = new Intent(context, Add.class);
        startActivityForResult(i, 1);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_CANCELED) {
            if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
                Log.d(TAG, "Reached state of returned information");
                String name = data.getStringExtra("taskName");
                String cat = data.getStringExtra("taskCat");
                String date = data.getStringExtra("taskDate");
                Log.d(TAG, "Set strings");
                Task tempTask = new Task(name, cat, date);
                listOfTasks.add(tempTask);
                Log.d(TAG, "Added new Task to taskArray");
                updateItems();

                makeToast(name + " added", Toast.LENGTH_SHORT);

            } else if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
                Integer iteration = data.getIntExtra("position", 0);
                Integer action = data.getIntExtra("action", 0);

                if(action == 0) {
                    makeToast("Should be deleting "+listOfTasks.get(iteration).getTaskName(), Toast.LENGTH_SHORT);

                    ArrayList<Task> tmpArr = new ArrayList<Task>();

                    Log.d("TASK NUMBER" ,"Number of Tasks: "+ listOfTasks.size() + "Iteration is " + iteration);

                    for(int i = 0; i < listOfTasks.size(); i++)
                    {

                        if(i != iteration)
                        {
                            tmpArr.add( listOfTasks.get(i) );
                            Log.d("TROUBLESHOOT" ,"Saved, "+ listOfTasks.get(i).getTaskName());
                        }
                        Log.d("LOOP" ,"Pass, i = " + i + ", tmpArr is now size " + tmpArr.size());
                    }



                    listOfTasks.clear();
                    listOfTasks = tmpArr;
                    Log.d("TASK NUMBER" ,"New number of Tasks: "+ listOfTasks.size());
                }
                else if(action == 1){
                    String name = data.getStringExtra("taskName");
                    String cat = data.getStringExtra("taskCat");
                    String date = data.getStringExtra("taskDate");

                    listOfTasks.get(iteration).setTaskName(name);
                    listOfTasks.get(iteration).setCategory(cat);
                    listOfTasks.get(iteration).setTaskDate(date);
                }

                updateItems();
            }
        }
    }

    public void makeToast(String message, int duration) {
        Context context = getApplicationContext();

        Toast toast = Toast.makeText(context, message, duration);
        toast.show();
    }

    public void updateItems() {

        adapter.notifyDataSetChanged();
        //adapter = new MyListAdapter(this, listOfTasks);
    }


}
