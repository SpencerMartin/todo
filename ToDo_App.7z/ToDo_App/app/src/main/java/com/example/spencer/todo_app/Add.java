package com.example.spencer.todo_app;

import android.app.ActionBar;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class Add extends Activity {

    EditText nameFld;
    EditText catFld;
    Button confirm;
    Button setDate;
    private TextView dateView;
    Calendar cal;
    private int year, month, day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        nameFld = (EditText) findViewById(R.id.taskNameField);
        catFld = (EditText) findViewById(R.id.categoryField);
        confirm = (Button) findViewById(R.id.add_task_button);
        setDate = (Button) findViewById(R.id.set_date_button);
        dateView = (TextView) findViewById(R.id.dateTextView);

        getActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_add, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        } else if (id == android.R.id.home) {
            Intent output = new Intent();
            setResult(Activity.RESULT_CANCELED, output);
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    public void add_button_clicked(View view) {
        Intent output = new Intent();
        output.putExtra("taskName", nameFld.getText().toString());
        output.putExtra("taskCat", catFld.getText().toString());
        output.putExtra("taskDate", dateView.getText().toString());
        setResult(Activity.RESULT_OK, output);

        finish();
    }

    @SuppressWarnings("deprecation")
    public void dateButtonClicked(View view) {
        showDialog(999);
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this, myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
            // TODO Auto-generated method stub
            // arg1 = year
            // arg2 = month
            // arg3 = day
            showDate(arg1, arg2 + 1, arg3);
        }
    };

    private void showDate(int year, int month, int day) {
        dateView.setText(new StringBuilder().append(month).append("/")
                .append(day).append("/").append(year));
    }

}
